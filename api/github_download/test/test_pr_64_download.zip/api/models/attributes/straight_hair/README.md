# Straight Hair trainings
* [**[FEATURE] Attributes: new YOLO-based straight hair model #64**](https://github.com/cimacorporate/004-body-part-segmentation/pull/64)